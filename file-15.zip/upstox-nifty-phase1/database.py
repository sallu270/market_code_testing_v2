from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Any

class MarketDatabase:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._connection = sqlite3.connect(
            str(path),
            check_same_thread=False,
            timeout=30,
        )
        self._connection.row_factory = sqlite3.Row
        self._configure()
        self._create_schema()

    def _configure(self) -> None:
        with self._lock:
            self._connection.execute("PRAGMA journal_mode=WAL;")
            self._connection.execute("PRAGMA synchronous=NORMAL;")
            self._connection.execute("PRAGMA foreign_keys=ON;")
            self._connection.commit()

    def _create_schema(self) -> None:
        with self._lock:
            self._connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS ticks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    instrument_key TEXT NOT NULL,
                    exchange_timestamp_ms INTEGER NOT NULL,
                    received_timestamp_ms INTEGER NOT NULL,
                    ltp REAL NOT NULL,
                    last_quantity REAL,
                    average_price REAL,
                    volume REAL,
                    open_interest REAL,
                    bid_price REAL,
                    bid_quantity REAL,
                    ask_price REAL,
                    ask_quantity REAL,
                    raw_json TEXT NOT NULL,
                    UNIQUE(
                        instrument_key,
                        exchange_timestamp_ms,
                        ltp,
                        received_timestamp_ms
                    )
                );

                CREATE INDEX IF NOT EXISTS idx_ticks_instrument_time
                    ON ticks(instrument_key, exchange_timestamp_ms DESC);

                CREATE TABLE IF NOT EXISTS candles_1m (
                    instrument_key TEXT NOT NULL,
                    candle_start_ms INTEGER NOT NULL,
                    open REAL NOT NULL,
                    high REAL NOT NULL,
                    low REAL NOT NULL,
                    close REAL NOT NULL,
                    volume REAL NOT NULL DEFAULT 0,
                    open_interest REAL,
                    tick_count INTEGER NOT NULL DEFAULT 0,
                    is_closed INTEGER NOT NULL DEFAULT 0,
                    updated_at_ms INTEGER NOT NULL,
                    PRIMARY KEY(instrument_key, candle_start_ms)
                );

                CREATE INDEX IF NOT EXISTS idx_candles_instrument_time
                    ON candles_1m(instrument_key, candle_start_ms DESC);

                CREATE TABLE IF NOT EXISTS strategy_trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    trade_id TEXT UNIQUE NOT NULL,
                    trade_date TEXT,
                    side TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    instrument_key TEXT NOT NULL,
                    underlying_key TEXT,
                    strike REAL NOT NULL,
                    lot_size INTEGER NOT NULL DEFAULT 65,
                    entry_time_ist TEXT NOT NULL,
                    entry_price REAL NOT NULL,
                    entry_timestamp_ms INTEGER NOT NULL,
                    exit_time_ist TEXT,
                    exit_price REAL,
                    exit_timestamp_ms INTEGER,
                    exit_reason TEXT,
                    pnl_points REAL,
                    net_pnl REAL,
                    status TEXT NOT NULL,
                    spot_price REAL,
                    atm_strike REAL
                );

                CREATE TABLE IF NOT EXISTS strategy_signals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp_ist TEXT NOT NULL,
                    timestamp_ms INTEGER NOT NULL,
                    instrument_name TEXT,
                    side TEXT NOT NULL,
                    strike REAL NOT NULL,
                    contract_key TEXT NOT NULL,
                    ltp REAL NOT NULL,
                    prev_ltp REAL,
                    qty_delta REAL,
                    val_lakhs REAL,
                    day_high REAL,
                    prev_close REAL,
                    action_taken TEXT NOT NULL,
                    bid_price REAL,
                    ask_price REAL,
                    spread_pct REAL,
                    oi_change REAL,
                    confidence TEXT
                );
                """
            )
            self._connection.commit()

            # --- Live migration: add new columns to existing tables if missing ---
            self._add_column_if_missing("strategy_trades", "trade_date", "TEXT")
            self._add_column_if_missing("strategy_trades", "underlying_key", "TEXT")
            self._add_column_if_missing("strategy_trades", "spot_price", "REAL")
            self._add_column_if_missing("strategy_trades", "atm_strike", "REAL")
            self._add_column_if_missing("strategy_signals", "instrument_name", "TEXT")
            self._add_column_if_missing("strategy_signals", "bid_price", "REAL")
            self._add_column_if_missing("strategy_signals", "ask_price", "REAL")
            self._add_column_if_missing("strategy_signals", "spread_pct", "REAL")
            self._add_column_if_missing("strategy_signals", "oi_change", "REAL")
            self._add_column_if_missing("strategy_signals", "confidence", "TEXT")

            # Backfill trade_date and underlying_key for any existing trades
            try:
                self._connection.execute(
                    """
                    UPDATE strategy_trades
                    SET trade_date = strftime('%Y-%m-%d', datetime(entry_timestamp_ms / 1000, 'unixepoch', '+330 minutes'))
                    WHERE trade_date IS NULL AND entry_timestamp_ms IS NOT NULL;
                    """
                )
                self._connection.execute(
                    """
                    UPDATE strategy_trades
                    SET underlying_key = CASE
                        WHEN symbol LIKE '%BANKNIFTY%' THEN 'NSE_INDEX|Nifty Bank'
                        WHEN symbol LIKE '%SENSEX%' THEN 'BSE_INDEX|SENSEX'
                        ELSE 'NSE_INDEX|Nifty 50'
                    END
                    WHERE underlying_key IS NULL;
                    """
                )
                self._connection.execute(
                    """
                    UPDATE strategy_signals
                    SET instrument_name = CASE
                        WHEN strike >= 70000 THEN 'SENSEX'
                        WHEN strike >= 45000 THEN 'BANKNIFTY'
                        ELSE 'NIFTY'
                    END
                    WHERE instrument_name IS NULL;
                    """
                )
                self._connection.commit()
            except Exception:
                pass

    def _add_column_if_missing(self, table: str, column: str, col_type: str) -> None:
        """ALTER TABLE … ADD COLUMN when the column does not yet exist (idempotent)."""
        try:
            existing = {
                row[1]
                for row in self._connection.execute(f"PRAGMA table_info({table})").fetchall()
            }
            if column not in existing:
                self._connection.execute(
                    f"ALTER TABLE {table} ADD COLUMN {column} {col_type}"
                )
                self._connection.commit()
        except Exception as exc:
            import logging
            logging.getLogger("database").warning(
                "Could not add column %s.%s: %s", table, column, exc
            )

    def insert_tick(self, tick: dict[str, Any]) -> None:
        with self._lock:
            self._connection.execute(
                """
                INSERT OR IGNORE INTO ticks (
                    instrument_key,
                    exchange_timestamp_ms,
                    received_timestamp_ms,
                    ltp,
                    last_quantity,
                    average_price,
                    volume,
                    open_interest,
                    bid_price,
                    bid_quantity,
                    ask_price,
                    ask_quantity,
                    raw_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    tick["instrument_key"],
                    tick["exchange_timestamp_ms"],
                    tick["received_timestamp_ms"],
                    tick["ltp"],
                    tick.get("last_quantity"),
                    tick.get("average_price"),
                    tick.get("volume"),
                    tick.get("open_interest"),
                    tick.get("bid_price"),
                    tick.get("bid_quantity"),
                    tick.get("ask_price"),
                    tick.get("ask_quantity"),
                    json.dumps(tick.get("raw", {}), separators=(",", ":")),
                ),
            )
            self._connection.commit()

    def upsert_candle(self, candle: dict[str, Any]) -> None:
        with self._lock:
            self._connection.execute(
                """
                INSERT INTO candles_1m (
                    instrument_key,
                    candle_start_ms,
                    open,
                    high,
                    low,
                    close,
                    volume,
                    open_interest,
                    tick_count,
                    is_closed,
                    updated_at_ms
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(instrument_key, candle_start_ms)
                DO UPDATE SET
                    open = excluded.open,
                    high = excluded.high,
                    low = excluded.low,
                    close = excluded.close,
                    volume = excluded.volume,
                    open_interest = excluded.open_interest,
                    tick_count = excluded.tick_count,
                    is_closed = excluded.is_closed,
                    updated_at_ms = excluded.updated_at_ms
                """,
                (
                    candle["instrument_key"],
                    candle["candle_start_ms"],
                    candle["open"],
                    candle["high"],
                    candle["low"],
                    candle["close"],
                    candle.get("volume", 0),
                    candle.get("open_interest"),
                    candle.get("tick_count", 0),
                    1 if candle.get("is_closed") else 0,
                    candle["updated_at_ms"],
                ),
            )
            self._connection.commit()

    def mark_candle_closed(
        self,
        instrument_key: str,
        candle_start_ms: int,
        updated_at_ms: int,
    ) -> None:
        with self._lock:
            self._connection.execute(
                """
                UPDATE candles_1m
                SET is_closed = 1, updated_at_ms = ?
                WHERE instrument_key = ? AND candle_start_ms = ?
                """,
                (updated_at_ms, instrument_key, candle_start_ms),
            )
            self._connection.commit()

    def latest_ticks(
        self,
        limit: int = 100,
        instrument_key: str | None = None,
    ) -> list[dict[str, Any]]:
        safe_limit = max(1, min(limit, 2000))
        with self._lock:
            if instrument_key:
                rows = self._connection.execute(
                    """
                    SELECT
                        instrument_key,
                        exchange_timestamp_ms,
                        received_timestamp_ms,
                        ltp,
                        last_quantity,
                        average_price,
                        volume,
                        open_interest,
                        bid_price,
                        bid_quantity,
                        ask_price,
                        ask_quantity
                    FROM ticks
                    WHERE instrument_key = ?
                    ORDER BY exchange_timestamp_ms DESC, id DESC
                    LIMIT ?
                    """,
                    (instrument_key, safe_limit),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    """
                    SELECT
                        instrument_key,
                        exchange_timestamp_ms,
                        received_timestamp_ms,
                        ltp,
                        last_quantity,
                        average_price,
                        volume,
                        open_interest,
                        bid_price,
                        bid_quantity,
                        ask_price,
                        ask_quantity
                    FROM ticks
                    ORDER BY exchange_timestamp_ms DESC, id DESC
                    LIMIT ?
                    """,
                    (safe_limit,),
                ).fetchall()
        return [dict(row) for row in rows]

    def latest_candles(
        self,
        instrument_key: str | None = None,
        limit: int = 120,
    ) -> list[dict[str, Any]]:
        safe_limit = max(1, min(limit, 2000))

        with self._lock:
            if instrument_key:
                rows = self._connection.execute(
                    """
                    SELECT *
                    FROM candles_1m
                    WHERE instrument_key = ?
                    ORDER BY candle_start_ms DESC
                    LIMIT ?
                    """,
                    (instrument_key, safe_limit),
                ).fetchall()
            else:
                rows = self._connection.execute(
                    """
                    SELECT *
                    FROM candles_1m
                    ORDER BY candle_start_ms DESC
                    LIMIT ?
                    """,
                    (safe_limit,),
                ).fetchall()

        return list(reversed([dict(row) for row in rows]))

    def instruments(self) -> list[str]:
        with self._lock:
            rows = self._connection.execute(
                """
                SELECT instrument_key
                FROM (
                    SELECT DISTINCT instrument_key FROM ticks
                    UNION
                    SELECT DISTINCT instrument_key FROM candles_1m
                )
                ORDER BY instrument_key
                """
            ).fetchall()
        return [str(row["instrument_key"]) for row in rows]

    def counts(self) -> dict[str, int]:
        with self._lock:
            ticks = self._connection.execute(
                "SELECT COUNT(*) AS count FROM ticks"
            ).fetchone()["count"]
            candles = self._connection.execute(
                "SELECT COUNT(*) AS count FROM candles_1m"
            ).fetchone()["count"]

        return {"ticks": int(ticks), "candles": int(candles)}

    def insert_strategy_trade(self, trade: dict[str, Any]) -> None:
        with self._lock:
            self._connection.execute(
                """
                INSERT OR REPLACE INTO strategy_trades (
                    trade_id, trade_date, side, symbol, instrument_key, underlying_key,
                    strike, lot_size, entry_time_ist, entry_price, entry_timestamp_ms,
                    exit_time_ist, exit_price, exit_timestamp_ms, exit_reason,
                    pnl_points, net_pnl, status, spot_price, atm_strike
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    trade["trade_id"],
                    trade.get("trade_date"),
                    trade["side"],
                    trade["symbol"],
                    trade["instrument_key"],
                    trade.get("underlying_key"),
                    trade["strike"],
                    trade.get("lot_size", 65),
                    trade["entry_time_ist"],
                    trade["entry_price"],
                    trade["entry_timestamp_ms"],
                    trade.get("exit_time_ist"),
                    trade.get("exit_price"),
                    trade.get("exit_timestamp_ms"),
                    trade.get("exit_reason"),
                    trade.get("pnl_points"),
                    trade.get("net_pnl"),
                    trade["status"],
                    trade.get("spot_price"),
                    trade.get("atm_strike"),
                ),
            )
            self._connection.commit()

    def update_strategy_trade(self, trade: dict[str, Any]) -> None:
        with self._lock:
            self._connection.execute(
                """
                UPDATE strategy_trades
                SET exit_time_ist = ?,
                    exit_price = ?,
                    exit_timestamp_ms = ?,
                    exit_reason = ?,
                    pnl_points = ?,
                    net_pnl = ?,
                    status = ?
                WHERE trade_id = ?
                """,
                (
                    trade.get("exit_time_ist"),
                    trade.get("exit_price"),
                    trade.get("exit_timestamp_ms"),
                    trade.get("exit_reason"),
                    trade.get("pnl_points"),
                    trade.get("net_pnl"),
                    trade["status"],
                    trade["trade_id"],
                ),
            )
            self._connection.commit()

    def get_strategy_trades(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._connection.execute(
                """
                SELECT * FROM strategy_trades
                ORDER BY entry_timestamp_ms DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def insert_strategy_signal(self, sig: dict[str, Any]) -> None:
        with self._lock:
            self._connection.execute(
                """
                INSERT INTO strategy_signals (
                    timestamp_ist, timestamp_ms, instrument_name, side, strike,
                    contract_key, ltp, prev_ltp, qty_delta,
                    val_lakhs, day_high, prev_close, action_taken,
                    bid_price, ask_price, spread_pct, oi_change, confidence
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    sig["timestamp_ist"],
                    sig["timestamp_ms"],
                    sig.get("instrument_name"),
                    sig["side"],
                    sig["strike"],
                    sig["contract_key"],
                    sig["ltp"],
                    sig.get("prev_ltp"),
                    sig.get("qty_delta"),
                    sig.get("val_lakhs"),
                    sig.get("day_high"),
                    sig.get("prev_close"),
                    sig["action_taken"],
                    sig.get("bid_price"),
                    sig.get("ask_price"),
                    sig.get("spread_pct"),
                    sig.get("oi_change"),
                    sig.get("confidence"),
                ),
            )
            self._connection.commit()

    def get_strategy_signals(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._connection.execute(
                """
                SELECT * FROM strategy_signals
                ORDER BY timestamp_ms DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def close(self) -> None:
        with self._lock:
            self._connection.close()